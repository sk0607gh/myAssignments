// May 25 Session - Template Literal

// Eg 1: ${}

let totTestCase =  200;
let outPut      =  `There are ${totTestCase} testcases`
console.log(outPut);
