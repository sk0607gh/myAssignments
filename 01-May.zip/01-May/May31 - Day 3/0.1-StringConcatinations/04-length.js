// May 25 Session - Know the length of the String

let course = "Playwright" ;
console.log(`Length of the course is :  ${course.length}`);

/*
NOTE:
Count for finding the Length starts from 1
*/
