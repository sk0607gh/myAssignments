// May 25 Session - index Of

let course = "Playwright" ;

console.log(`Length of the course1 is :  ${course.includes('rig')}`);
                            // OR
console.log(`Length of the course1 is :  ${course.includes('r_g')}`);
                            //OR
console.log(`Length of the course2 is :  ${course.includes('Playwright')}`);
                            //OR
console.log(`Length of the course3 is :  ${course.includes('Playwroght')}`);
