// May 25 Session - SPLIT


let course = "Playwright Testing Tool" ;
let array  = course.split();
console.log("1st O/p... :" +array) ;

let course1 = "Playwright Testing Tool" ;
let array2 = course1.split("");
console.log("2nd O/p... :" ) 
console.log(array2) ;

