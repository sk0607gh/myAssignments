// May 25 Session - SLICE

let course1 = "Playwright" ;
let sliceValue1 = course1.slice(1,4) ;
console.log("O/p 1 is... : " + sliceValue1);

let course2 = "Playwright" ;
let sliceValue2 = course2.slice(1) ;
console.log("O/p 2 is... : " + sliceValue2);

//For - it will take the value from the reverse Order
let course3 = "Playwright" ;
let sliceValue3 = course3.slice(-4,-1) ;
let sliceValue4 = course3.slice(-1,-4) ;
console.log("O/p 3 is... : " + sliceValue3);
console.log("O/p 3 is... : " + sliceValue4);

/* NOTE:
Supports both +ve & -ve values  */
