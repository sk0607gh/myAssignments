// May 25 Session - charAt

// Using charAt we can print the letter for which we are mentioning the position .

let course = "Playwright" ;
console.log(`Length of the course is :  ${course.charAt(5)}`);

/*
NOTE:
Count for finding the "char" starts from 0
*/