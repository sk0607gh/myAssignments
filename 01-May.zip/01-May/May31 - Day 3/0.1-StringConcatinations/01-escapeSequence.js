//May 31 - String Concatination

// Single Quotes

let testResult1 = 'Completed\' practising todays recording session ' ;
console.log("O/P is... : " +testResult);


//Double Quotes

let testResult2 = "Completed it, successfully\"practising todays recording session\ "";
console.log("O/P is... : " +testResult2);
