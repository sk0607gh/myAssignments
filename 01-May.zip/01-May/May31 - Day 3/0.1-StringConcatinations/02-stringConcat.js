//May 31 - String Concatination

//String Concatination - Sample 1 

let userFrstName = "Sunil"
let userID       = 123
let result1       = "Joining a String & a NUmber...:" +userID.toString().concat(userFrstName);
let result2       = "Joining a String & a NUmber...:" +userFrstName.concat(userID).toString();
console.log("o/p is...:" +result1);
console.log("o/p is...:" +result2);






