// In the Terminal ,  print it in a reverse order

//Other way of dng it

let testData = "check"
let chars = testData.split("").reverse().join("");
console.log(chars);
