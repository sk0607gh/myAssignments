//  VAR allows the user to Re-Declare (YES)
//  VAR allows the user to Re-Assign  (YES)

// ReDeclare
var abc = 10;  // Declaration
var abc = 20;  // Re-Declaration
console.log("ABC Value is : " +abc);

var fName = "Sunil";
var fName =  "SK";
console.log("FNAME is : " +fName);


//Reassign
var yyy = 30;
yyy     = 40;
console.log("YYY value is : " + yyy);

var zzz = "Sunil";
zzz     = "SK" 
console.log("ZZZ Name is : " +zzz);


