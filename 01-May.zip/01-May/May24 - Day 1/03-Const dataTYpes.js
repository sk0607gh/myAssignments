// CONST - Integer
const mobileNUmber = 9884989011;
console.log("Integer Value is : " +mobileNUmber);
console.log(typeof mobileNUmber);

// CONST - Decimal Value
const rateOfInterest = 7.5;
console.log("Decimal Value is : " +rateOfInterest);
console.log(typeof rateOfInterest);

// CONST - String - Using Nos
const landLineNo = "123456789";
console.log("String Value is : " +landLineNo);
console.log(typeof landLineNo);

// CONST - String - Using text
const compName = 'Test Leaf';
console.log("String Value is : " +compName);
console.log(typeof landLineNo);

// CONST - Big INT ( When n is there at the last it will identify it as Big Int )
const population = 1232323232323232232333244n;
console.log("BigInt Value is : " +population);
console.log(typeof population);

//Boolean
const checkCondition = "True";
console.log("Boolean Value is :" +checkCondition);
console.log(typeof checkCondition);

//Undefined ( Below throws an error, as in CONST it wont work when the VAR is not Initialized)
/* const bankAcctNo ;
console.log("Undefined Value is :" +bankAcctNo);
console.log(typeof bankAcctNo); */

//NULL
const landNO = null;
console.log("NUll Value is : " +landNO);
console.log(typeof landNO);  
// Above O/p : Object  >>  Where this is a historical bug which was done in the Initial Developement Phase of the framework.