// May 25 Session - Object Way of declaring a String

let fName    = new String("Sunil")
let userName = new String("Sunil")


/* Note
In the above case eventhough it is having the same value, since we have used an Sting Object say new,
when it comes to storage - 
        * fname will be stored in DB100 
        * userName will be stored in DB101. 
This is what we call it as "HEAP Memory" */