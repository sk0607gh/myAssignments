// May 25 Session  - Control Selection -  IF Statement

browserName = "Chrome"

function getBrowserUsed () {

        if (browserName === "Chromee") {
                    console.log("Browser used in the application...." +browserName);
                    
        } else {
            console.log("Browser Version used in not supported....");
        }

}

getBrowserUsed() ;
