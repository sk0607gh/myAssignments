// May 25 Session  - Control Iteration -  FOR EACH Statement using IIFE Function

/* NOTE: In the below we are having some list of Values, 
where we r gng to store list of Values as an array and store it in a Variable */

let automationTools = ["Playwright", "Selenium", "Load Runner"]

        automationTools.forEach(function (automation){
                    console.log("List of Automation Tools are as follows using IIFE Function..." +automation);
                    
        }
);