//May 25 Session - While Loop 

// Do loop for sure will run atleast ONCE.

let num = 10;
do {
    console.log("NUM value is : " + num);
    num ++;
    
} while (num <= 5) 

