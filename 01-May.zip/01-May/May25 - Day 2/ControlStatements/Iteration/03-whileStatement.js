//May 25 Session - While Loop 

let count = 5

while (count) {
    console.log("Number of Values is..." +count);
    count --
    
}












/* NOTE:
Runs until the constinue is true */
