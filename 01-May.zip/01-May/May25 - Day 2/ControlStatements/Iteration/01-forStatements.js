// May 25 Session  - Control Iteration -  FOR LOOP Statement

for (let index = 0; index < 5; index++) {
    
         console.log("Index Value is...." + index);
    
}

console.log("DONE...." );