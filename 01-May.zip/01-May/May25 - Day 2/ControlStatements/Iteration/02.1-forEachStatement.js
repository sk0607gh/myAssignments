// May 25 Session  - Control Iteration -  FOR EACH Statement using ARROW Function

/* NOTE: In the below we are having some list of Values, 
where we r gng to store list of Values as an array and store it in a Variable */

let automationTools  = ["Playwright", "Selenium", "Load Runner"] ;

automationTools.forEach ( (automation) => {
        console.log("Values stored in the arrays are as follows..." +automation);
        
}
)