let x=10;
x+=5
console.log("Value of + X is :"+x);  //O/P : 10+5 = 15

x-=5
console.log("Value of - X is :"+x);  //O/P : 15-5 = 10

x*=5
console.log("Value of * X is :"+x);  //O/P : 10*5 = 50