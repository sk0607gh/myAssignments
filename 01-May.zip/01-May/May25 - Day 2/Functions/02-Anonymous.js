// ANONYMOUS FUNCTION

let sample = function() {

    console.log("This is a example for the Anonymous Function....");
    
}

sample();