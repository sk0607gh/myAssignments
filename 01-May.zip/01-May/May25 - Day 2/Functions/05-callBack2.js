//  June 1 - Call Back Function with Double Parameter using CallBack


function hello (message,callback) {

        console.log("Hellooo .. " + message);

        callback();
        
}

function displayThanks(){

         console.log("Thank You....");
}

hello("GUYS",displayThanks);




