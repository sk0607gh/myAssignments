// Immediate Invoked Function Expression

(
    function(log) {
        console.log("This is an example of the IIFE Function...");
    }
)

()