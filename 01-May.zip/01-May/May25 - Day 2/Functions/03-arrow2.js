//Arrow Function with Hoisting Functionality

sampleArrow ();

let sampleArrow = () => {
    console.log("This is an example for the Arrow Function...");
}

//sampleArrow ();




// NOTE:
// Hoisting wont work in the case of Arrow Function