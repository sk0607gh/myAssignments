// ANONYMOUS FUNCTION with Hoisting Functionality

sample();

let sample = function() {

    console.log("This is a example for the Anonymous Function....");
    
}

//sample();




// NOTE:
// Hoisting wont work in the case of Anonymous Function