//  June 1 - Call Back Function with Double Parameter using CallBack and using set TImeout

function checkAvailability (movieName,callback) {

        console.log("Checking Movie Availability...");

setTimeout(() => {
        console.log(`Movie ${movieName} is available ...`);
        callback();
}, 10000);
        
        
}

function playMovie(){

         console.log("Playing the Movie...");
}

checkAvailability("IRON-MAN",playMovie);