// June 1 - Call Back Function with Single Parameter


function hello (message) {

        console.log("Hellooo .. " + message);
        
}

hello("GUYS");