//Arrow Function 

//Example 1
let sampleArrow = () => {
    console.log("This is an example for the Arrow Function...");
}

sampleArrow ();

//Example 2

//const sampleArrow2 = (a,b) => a*b;
            // OR
let sampleArrow2 = (a,b) => a*b;

console.log("MUltiplying the Values of A & B  : " +sampleArrow2(2,3));
