// Named Functions with Hoisting Functionality

helloWorld();

function helloWorld() {
    
        console.log("Hellooooo World......");
        
}

//helloWorld();

// NOTE:
// Hoisting works in the case of Named Function