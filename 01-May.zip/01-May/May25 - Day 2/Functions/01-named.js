// Named Functions

const name = "Sunil"

function helloWorld() {
    
        console.log("Hello World......");

        console.log("Whats the Name......" +name);
        
}

function addValue() {
        
        var     a = 10
        let     b = 20;
        return  c = a+b;
                
}


helloWorld();

/* For the below wont get anything displayed in the Console why bec it is returning a value which we need to get and 
display it using Console.LOG */

addValue();  

//Getting the Return value, storing it in a VAR and printing the value that is stored in the Variable.

var totValue = addValue();
console.log( "Return SUM VALUE is : " + totValue );
                        //OR
console.log( "Return SUM VALUE is : " + addValue() );




