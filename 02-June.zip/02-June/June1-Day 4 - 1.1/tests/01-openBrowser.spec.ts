//  June 1 - Config session  - Launching a Browser with the Workers & Project Concept

import { chromium, firefox, test, webkit } from "@playwright/test";

test(`Test to launch the Browser`, async() => {

// Below Line launches the Chromium Browser and the no of time the Browser launching will be based on the Browser that 
// we have mentioned in the "playwright.config.ts" FILE
        //const browser  =   await chromium.launch();
// Below Line is used to launch the Browser and we specify we want to launch in EDGE/Chrome/Firefox Browser.
// Therefore it will consider nly the below line and wont consider the Browser mentioned in the "playwright.config.ts" FILE
        //const browser  =   await chromium.launch({channel:'msedge'});
        const browser  =   await chromium.launch({channel:'chrome'});
        //const browser  =   await firefox.launch();
        //const browser  =   await webkit.launch();

        const context  =   await browser.newContext();
        const openURL  =   await context.newPage();

        await openURL.goto("https://www.myntra.com/");

        console.log("...........COMPLETED........");

        const url     =    openURL.url();
        console.log(`URL of the Page is.... ${url}`);
        console.log(`Title of the Page is.... ${await openURL.title() }`);  
        await openURL.waitForTimeout(5000) ;
        
}
)