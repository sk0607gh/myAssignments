// List of changes that we have made in the "playwright.config.ts" FILE

/* 
1.
    launchOptions:{
      args:['--start-maximized'],  // This line maximises the window
    }, viewport:null  

2.
    {
      name: 'chromium',
      use: { ...devices['Chrome'],channel:'msedge' },
    }

3.
    headless:false,
    trace: 'on-first-retry', 

    
4. 
   // In this case simultaneous Execution happens
   workers: process.env.CI ? 1 : undefined,
  

  //In this case simulatneous execution wont happen.
  1 Worker 1 Projects

  Project 1: Frst the Project 1 Browser will Open, run the code and then closes it. Execution is DONE 


  //In the below simulatneous execution wont happen.
  1 Worker 2 Projects

  Project 1: Frst the Project 1 Browser will Open, run the code and then closes it. 
  Project 2: Now Project 2 will now open, RUN the CODE and gets CLOSED.

*/