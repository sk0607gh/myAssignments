// June 1 Session - Functions

import { defineConfig, devices } from '@playwright/test';

        /**
         * Read environment variables from file.
         * https://github.com/motdotla/dotenv
         */
        // import dotenv from 'dotenv';
        // import path from 'path';
        // dotenv.config({ path: path.resolve(__dirname, '.env') });

        /**
         * See https://playwright.dev/docs/test-configuration.
         */
export default defineConfig({
/*        All our codings that we write in the tests will be mapped to the testDir */
          testDir: './tests',
/*        When we give "TRUE" all the 3 Browsers gets launched.  */
          fullyParallel: true,
/*           When we give "FALSE" 1st 1 Browser gets Launched and then gets closed. Only then the 2 Browser launches  */
          // fullyParallel: false, 
          /* Fail the build on CI if you accidentally left test.only in the source code. */
          forbidOnly: !!process.env.CI,
          /* Retry on CI only */
          retries: process.env.CI ? 2 : 0,
/* Opt out of parallel tests on CI. */
/* Normally when we give Undefined it will open 3 Browsers. Max 4 */
          //workers: process.env.CI ? 1 : undefined,
// When we are giving just 1 Worker and below when we give 3 
          workers: 1,
          /* Reporter to use. See https://playwright.dev/docs/test-reporters */
          reporter: 'html',
          /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
          use: {
                /* Base URL to use in actions like `await page.goto('/')`. */
                // baseURL: 'http://localhost:3000',

                /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
/* When this is given , browser does not gets Opened and just print the o/P in the Terminal */
                headless:true, 
/* When this is given , browser gets Opened */
                //headless:false,  
                trace: 'on-first-retry',
/*              This will maximise the window according to our wish. */
                launchOptions:{
                  args:['--start-maximized'],  // This line maximises the window
                }, viewport:null               //prevents playwright from overriding the window size
          },

          /* Configure projects for major browsers */
          projects: [

/*            When we use the below line, code gets executed only once  * /
              /*     {
                    name: 'chromium',
                    use: { ...devices['Chrome'],channel:'msedge' }, // to launch in Edge Browser
                    //use: { ...devices['Chrome'],channel:'chrome' },   // to launch in Chrome Browser
                  } */

/*          *****************************   Below we have 3 PROJECTS  ****************************  */
/*            When the below 3 is not commented then the browser opens 3 times. When we use the above code it only runs once
              Consider the below as 3 Projects. Therefore all the Project will execute the code.  */
                  {
                    name: 'chromium',
                    use: { ...devices['Desktop Chrome'] },
                  },
                
/*                {
                    name: 'firefox',
                    use: { ...devices['Desktop Firefox'] },
                  },  

                  {
                    name: 'webkit',
                    use: { ...devices['Desktop Safari'] },
                  },   */

                  /********      Test against MOBILE viewports. ************/
                  // {
                  //   name: 'Mobile Chrome',
                  //   use: { ...devices['Pixel 5'] },
                  // },
                  // {
                  //   name: 'Mobile Safari',
                  //   use: { ...devices['iPhone 12'] },
                  // },

                  /* Test against branded browsers. */
                  // {
                  //   name: 'Microsoft Edge',
                  //   use: { ...devices['Desktop Edge'], channel: 'msedge' },
                  // },
                  // {
                  //   name: 'Google Chrome',
                  //   use: { ...devices['Desktop Chrome'], channel: 'chrome' },
                  // },
          ],

          /* Run your local dev server before starting the tests */
          // webServer: {
          //   command: 'npm run start',
          //   url: 'http://localhost:3000',
          //   reuseExistingServer: !process.env.CI,
          // },
});
