//  June 1 - Config session  - Passing Headless detail via the CODE and not from "config.ts"

import { chromium, firefox, test, webkit } from "@playwright/test";

test(`Test to launch the Browser`, async() => {

  
        //const browser    =   await chromium.launch({headless:false,channel:'chrome'});
        //const browser  =   await chromium.launch({headless:true,channel:'Chrome'});
                                        //OR
        const browser    =   await chromium.launch({headless:false});
        //const browser  =   await chromium.launch({headless:true}); 

        //const browser  =   await chromium.launch({channel:'msedge'});
        //const browser  =   await chromium.launch({channel:'chrome'});
        //const browser  =   await firefox.launch();
        //const browser  =   await webkit.launch();

        const context  =   await browser.newContext();
        const openURL  =   await context.newPage();

        await openURL.goto("https://www.google.com/");

        console.log("...........COMPLETED........");

        const url     =    openURL.url();
        console.log(`URL of the Page is.... ${url}`);
        console.log(`Title of the Page is.... ${await openURL.title() }`);  
        await openURL.waitForTimeout(5000) ;
      
}
)


//NOTE:
/*
In this scenario we have commented the headless line in the "playwright.config.ts" nd we are main it in the Main Class
When u run the above code in the Terminal we have to give it in the below way
"npx playwright.......openBrowser.spec.ts --headed"
*/

