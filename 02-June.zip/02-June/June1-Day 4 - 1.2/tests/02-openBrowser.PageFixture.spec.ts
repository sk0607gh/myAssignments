//  June 1 - Config session  - Launching a Browser using PAGE FIXTURE


import { chromium, firefox, test, webkit } from "@playwright/test";


test(`Test to launch the Browser using PAGE FIXTURE`, async({page}) => {

        await page.goto("https://www.google.com/");

        console.log("...........COMPLETED........");

        const url     =    page.url();

        console.log(`URL of the Page is.... ${url}`);
                                //OR
        console.log(`URL of the Page is.... ` + url);   
        console.log(`Title of the Page is.... ${await page.title() }`);  
        await page.waitForTimeout(5000) ;                     
}
)